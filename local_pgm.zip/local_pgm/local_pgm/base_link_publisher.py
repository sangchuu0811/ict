import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point
from tf2_ros import Buffer, TransformListener, LookupException, ConnectivityException, ExtrapolationException
from rclpy.qos import QoSProfile


class BaseLinkPublisher(Node):
    def __init__(self):
        super().__init__('base_link_publisher')

        # 퍼블리셔 생성
        qos_profile = QoSProfile(depth=10)
        self.publisher_ = self.create_publisher(Point, 'base_link_position', qos_profile)

        # tf2 버퍼와 리스너 생성
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # 타이머 생성 (0.1초마다 위치 퍼블리시)
        self.timer = self.create_timer(0.1, self.publish_base_link_position)

    def publish_base_link_position(self):
        try:
            # map 또는 odom 프레임에서 base_link의 변환을 가져옴
            transform = self.tf_buffer.lookup_transform('map', 'base_link', rclpy.time.Time())
            
            # base_link의 위치 정보 (x, y, z)를 Point 메시지에 저장
            point = Point()
            point.x = transform.transform.translation.x
            point.y = transform.transform.translation.y
            point.z = transform.transform.translation.z
            
            # 위치 퍼블리시
            self.publisher_.publish(point)
            self.get_logger().info(f'Published base_link position: x={point.x}, y={point.y}, z={point.z}')

        except (LookupException, ConnectivityException, ExtrapolationException) as e:
            self.get_logger().warn(f'Could not transform base_link: {str(e)}')


def main(args=None):
    rclpy.init(args=args)
    node = BaseLinkPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
 